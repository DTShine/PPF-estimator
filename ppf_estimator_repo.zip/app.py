from flask import Flask, request, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///vehicles.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer, nullable=False)
    make = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50), nullable=False)
    submodel = db.Column(db.String(50))

@app.before_first_request
def create_tables():
    if not os.path.exists("vehicles.db"):
        db.create_all()

@app.route("/api/vehicles", methods=["GET"])
def get_vehicles():
    year = request.args.get("year")
    make = request.args.get("make")
    model = request.args.get("model")
    query = Vehicle.query
    if year:
        query = query.filter_by(year=int(year))
    if make:
        query = query.filter_by(make=make)
    if model:
        query = query.filter_by(model=model)
    vehicles = query.all()
    return jsonify([{
        "id": v.id,
        "year": v.year,
        "make": v.make,
        "model": v.model,
        "submodel": v.submodel
    } for v in vehicles])

@app.route("/api/calculate", methods=["POST"])
def calculate():
    data = request.json
    film = data.get("film")
    coating = int(data.get("coating", 0))
    labor = int(data.get("labor", 1))

    film_prices = {
        "Suntek": 1375,
        "Xpel": 1398,
        "3M Pro Series": 1350
    }

    base = film_prices.get(film, 0)
    labor_cost = labor * 500
    total = base + coating + labor_cost

    return jsonify({
        "film": film,
        "film_cost": base,
        "coating_cost": coating,
        "labor_cost": labor_cost,
        "total": total
    })

@app.route("/")
def serve_index():
    return send_from_directory(".", "index.html")

if __name__ == "__main__":
    app.run(debug=True)
